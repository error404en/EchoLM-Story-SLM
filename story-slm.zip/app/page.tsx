'use client'

import { useMemo, useState } from 'react'
import {
  BookOpen,
  ChevronDown,
  Copy,
  Download,
  Feather,
  Gauge,
  Library,
  Menu,
  Moon,
  MoreHorizontal,
  PanelLeftClose,
  Play,
  RefreshCw,
  Sparkles,
  SunMedium,
  WandSparkles,
  X,
} from 'lucide-react'
import { EvaluationDashboard } from '@/components/evaluation-dashboard'

type ThemeName = 'ink' | 'ocean' | 'forest' | 'ember' | 'lunar'

const themeOptions: { id: ThemeName; label: string; description: string; swatch: string }[] = [
  { id: 'ink', label: 'Ink', description: 'Quiet focus', swatch: '#8f9bb0' },
  { id: 'ocean', label: 'Ocean', description: 'Deep & luminous', swatch: '#43c6c7' },
  { id: 'forest', label: 'Forest', description: 'Wild & warm', swatch: '#86a950' },
  { id: 'ember', label: 'Ember', description: 'Bright & brave', swatch: '#e88955' },
  { id: 'lunar', label: 'Lunar', description: 'Softly strange', swatch: '#9a8de3' },
]

const stories: Record<ThemeName, { title: string; body: string; note: string }> = {
  ink: {
    title: 'The room between words',
    body: 'At the edge of every sentence, there is a small room where the next thought waits. Mara found it by accident one Tuesday morning, when the rain wrote a silver line down the window and refused to move on.\n\nShe stepped inside with nothing but a question. By evening, she had returned with a map, a name she had forgotten, and the quiet certainty that the world was larger than the stories she had been telling herself.',
    note: 'A contemplative short story',
  },
  ocean: {
    title: 'The cartographer of tides',
    body: 'Every morning, Ilyan drew the same impossible coastline: a shore that only appeared beneath the moon. The villagers laughed until the sea began leaving letters in the sand.\n\nOn the seventh night, he followed the tide beyond the blue horizon and found a city breathing under glass. Its doors opened when he said his own name, and the water remembered everything he had tried to forget.',
    note: 'A luminous ocean fable',
  },
  forest: {
    title: 'A fox in the green hour',
    body: 'The fox arrived at the clearing just as the sun turned the leaves to coins. It carried a red thread in its teeth, and behind it the whole forest seemed to lean closer.\n\nNell followed until the path became a door. On the other side, her grandmother was waiting beside a kettle, exactly as she had been twenty years ago, smiling as though Nell had only been gone for an afternoon.',
    note: 'A folktale about returning',
  },
  ember: {
    title: 'The last lightkeeper',
    body: 'When the mountain began to burn, Sera climbed toward it with a lantern tucked beneath her coat. The old lightkeeper had promised that one flame could guide a village through any night.\n\nAt the summit, she found the dragon sleeping around the beacon. It opened one golden eye and asked what she was willing to carry home. Sera lifted the lantern. The dragon lifted its wing.',
    note: 'A warm-hearted adventure',
  },
  lunar: {
    title: 'The girl who borrowed the moon',
    body: 'Jun woke to discover that the moon had fallen into her teacup. It was no larger than a pearl, but it hummed with the memory of every night it had ever touched.\n\nShe carried it to the roof and held it up. For one breath, every sleeping dream in the city became visible: blue horses, unfinished songs, and a thousand doors waiting to be opened.',
    note: 'A softly strange dream',
  },
}

export default function Page() {
  const [theme, setTheme] = useState<ThemeName>('ocean')
  const [prompt, setPrompt] = useState('Write a story about a cartographer who maps the ocean at night.')
  const [temperature, setTemperature] = useState(72)
  const [length, setLength] = useState(54)
  const [isGenerating, setIsGenerating] = useState(false)
  const [showControls, setShowControls] = useState(true)
  const [copied, setCopied] = useState(false)
  const story = useMemo(() => stories[theme], [theme])

  function generate() {
    setIsGenerating(true)
    window.setTimeout(() => setIsGenerating(false), 1100)
  }

  function chooseTheme(nextTheme: ThemeName) {
    setTheme(nextTheme)
    const prompts: Record<ThemeName, string> = {
      ink: 'Write a quiet story about the room between words.',
      ocean: 'Write a story about a cartographer who maps the ocean at night.',
      forest: 'Write a folktale about a fox that knows the way home.',
      ember: 'Write an adventure about a lightkeeper and a sleeping dragon.',
      lunar: 'Write a dreamy story about a girl who borrows the moon.',
    }
    setPrompt(prompts[nextTheme])
  }

  async function copyStory() {
    await navigator.clipboard?.writeText(`${story.title}\n\n${story.body}`)
    setCopied(true)
    window.setTimeout(() => setCopied(false), 1600)
  }

  return (
    <main className="story-app" data-theme={theme}>
      <div className="ambient ambient-one" />
      <div className="ambient ambient-two" />
      <div className="ambient ambient-three" />
      <header className="topbar">
        <div className="brand-lockup">
          <div className="brand-mark"><Feather size={16} strokeWidth={2.4} /></div>
          <div><span className="brand-name">story<span>-</span>slm</span><span className="brand-status"><i /> local studio</span></div>
        </div>
        <div className="top-actions">
          <button className="icon-button desktop-only" aria-label="Open library" title="Open library"><Library size={18} /></button>
          <button className="icon-button desktop-only" aria-label="Toggle display theme" title="Toggle display theme"><SunMedium size={18} /></button>
          <button className="icon-button mobile-only" aria-label="Toggle controls" onClick={() => setShowControls(!showControls)}>{showControls ? <X size={18} /> : <Menu size={18} />}</button>
          <div className="avatar">A</div>
        </div>
      </header>

      <div className="workspace">
        <aside className={`control-rail ${showControls ? 'is-open' : ''}`}>
          <div className="rail-heading">
            <div><p className="eyebrow">CREATE</p><h1>Story studio</h1></div>
            <button className="collapse-button desktop-only" aria-label="Collapse controls" title="Collapse controls" onClick={() => setShowControls(false)}><PanelLeftClose size={18} /></button>
          </div>

          <div className="prompt-block">
            <label htmlFor="story-prompt">Your story begins with</label>
            <div className="prompt-field">
              <textarea id="story-prompt" value={prompt} onChange={(event) => setPrompt(event.target.value)} aria-label="Story prompt" />
              <span className="prompt-count">{prompt.length}/240</span>
            </div>
          </div>

          <section className="control-section" aria-labelledby="mood-title">
            <div className="section-label"><span id="mood-title">Atmosphere</span><span className="active-theme">{themeOptions.find((item) => item.id === theme)?.label}</span></div>
            <div className="theme-grid">
              {themeOptions.map((item) => (
                <button key={item.id} className={`theme-tile ${theme === item.id ? 'selected' : ''}`} onClick={() => chooseTheme(item.id)} aria-pressed={theme === item.id}>
                  <span className="theme-swatch" style={{ background: item.swatch }} />
                  <span>{item.label}</span>
                </button>
              ))}
            </div>
          </section>

          <section className="control-section parameter-section" aria-labelledby="parameters-title">
            <div className="section-label"><span id="parameters-title">Parameters</span><Gauge size={15} /></div>
            <label className="range-control"><span>Creativity <b>{temperature}%</b></span><input type="range" min="0" max="100" value={temperature} onChange={(event) => setTemperature(Number(event.target.value))} /></label>
            <label className="range-control"><span>Story length <b>{length}%</b></span><input type="range" min="0" max="100" value={length} onChange={(event) => setLength(Number(event.target.value))} /></label>
          </section>

          <div className="rail-footer">
            <button className={`generate-button ${isGenerating ? 'loading' : ''}`} onClick={generate} disabled={isGenerating}>
              {isGenerating ? <RefreshCw className="spin" size={18} /> : <WandSparkles size={18} />}
              <span>{isGenerating ? 'Finding the thread...' : 'Generate story'}</span><span className="shortcut">⌘ ↵</span>
            </button>
            <p className="model-note"><span className="pulse-dot" /> Story-SLM · 7B parameters</p>
          </div>
        </aside>

        <section className="story-canvas" aria-label="Generated story">
          <div className="canvas-toolbar">
            <div className="canvas-context"><span className="live-dot" /> <span>{isGenerating ? 'Composing a new story' : 'Generated just now'}</span></div>
            <div className="canvas-actions">
              <button onClick={copyStory} aria-label="Copy story" title={copied ? 'Copied' : 'Copy story'}><Copy size={17} /></button>
              <button aria-label="Download story" title="Download story"><Download size={17} /></button>
              <button aria-label="More story options" title="More story options"><MoreHorizontal size={18} /></button>
            </div>
          </div>
          <article className={`story-content ${isGenerating ? 'is-generating' : ''}`}>
            <div className="story-kicker"><BookOpen size={14} /> {story.note}</div>
            <h2>{story.title}</h2>
            <div className="story-rule" />
            {story.body.split('\n\n').map((paragraph) => <p key={paragraph}>{paragraph}</p>)}
            <div className="story-endmark"><span /> <Sparkles size={15} /> <span /></div>
          </article>
          <div className="canvas-bottom"><span>01 / 01</span><span>Crafted with intention</span><span>{copied ? 'Copied to clipboard' : 'A small story, made for you'}</span></div>
        </section>
      </div>

      <EvaluationDashboard />
    </main>
  )
}
